create
    definer = ylesp@`%` function docTypeTree(root int) returns varchar(10000)
begin 
DECLARE idlist varchar(10000);
select GROUP_CONCAT(tt.idlist) into idlist  from 	(SELECT
			@id idlist,
			(@lv :=@lv + 1) as lv,
			(
				SELECT
					@id := group_concat(id)
				FROM
					t_doctype
				WHERE
					find_in_set(parentid ,@id)
			) sub
		FROM
			t_doctype,
			(SELECT @id := root ,@lv := 0) vars
		WHERE
			@id IS NOT NULL) tt;
return idlist;
end;

