create
    definer = ylesp@`%` function func_nextid(tablename varchar(50)) returns int
BEGIN
    DECLARE idValue INT;
    DECLARE sqlString VARCHAR(200);
    UPDATE t_sequence SET ID=ID+1 WHERE NAME=tablename;
   IF ROW_COUNT()=0 THEN
     INSERT INTO t_sequence(ID,NAME) VALUES(0,tablename);
     SELECT IFNULL(ID,0) INTO idValue FROM t_sequence WHERE NAME=tablename;
   ELSE 
     SELECT ID INTO idValue FROM t_sequence WHERE NAME=tableName;
   END IF;
   RETURN idValue;
    END;

