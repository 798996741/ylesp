create
    definer = ylesp@`%` procedure pNextID(IN tablename varchar(50))
BEGIN
 DECLARE idValue INT;
 DECLARE sqlString VARCHAR(200);
 
 UPDATE t_sequence SET ID=ID+1 WHERE NAME=tablename;
 IF ROW_COUNT()=0 THEN
     SET sqlString=CONCAT('insert into t_sequence(ID,Name) select ifnull(max(ID),0)+1,''',tablename,''' from ',tablename);
     SET @insertSql=sqlString;
     PREPARE insertStmt FROM @insertSql;
     EXECUTE insertStmt;
     SELECT IFNULL(ID,0) INTO idValue FROM t_sequence WHERE NAME=tablename;
 ELSE 
 SELECT ID INTO idValue FROM t_sequence WHERE NAME=tableName;
 END IF;
 SELECT idValue;
 END;

